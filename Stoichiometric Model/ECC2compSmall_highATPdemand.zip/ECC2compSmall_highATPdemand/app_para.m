epsilon=1e-10;
basic_color=[0.7         0.7         0.7];
cr_color=[0.5         0.5           1];
br_color=[1         0.2         0.2];
nbr_color=[0.7         0.7         0.7];
text_color=[0  0  0];
macro_synth_color=[0  0  1];
macro_color=[0.9         0.9         0.5];
box_reaction_width=[0.04      0.0035];
box_reaction_height=[0.02        0.02];
box_macro_width=[0.04        0.04];
box_macro_height=[0.04       0.025];
fontsize_reaction=[8  10];
fontsize_macro=[11  11];
fluxmaps={
'Escherichia coli central metabolism','ColiCentralNetwork_Figure1_resize.png'
};
